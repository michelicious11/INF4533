var courriels = [
   {
       "from": "Capricia Marshall",
       "to": "Hillary Clinton",
       "date": "2012-05-31 09:44",
       "subject": "FROM HARVEY WEINSTEIN",
       "body": "Madame Secretary\n Harvey was hopeful that you would see his great interview with President Clinton last night!"
   },
   {
        "from": "Jake Sullivan",
        "to": "Hillary Clinton",
        "date": "2011-11-14 14:05",
        "subject": "KELLER",
        "body": "How Romney Could Win\nBy BILL KELLER\nElection Day is nearly a year off and the first primaries aren't until January, but I'm ready to skip ahead to the main event. The last" +
        "serious hope of the Tea Partiers, Rick Perry, and their last not-so-serious hope, Herman Cain, are in campaign death spirals. Unless God" +
        "has a cruel sense of humor, Newt Gingrich will pass like a tantrum. That leaves us with a• general election between two serious and" +
        "certifiably sane candidates. Phew!!"
    },
    {
        "from": "Unknown sender",
        "to": "Hillary Clinton",
        "date": "2010-08-23 02:00",
        "subject": "H: Yes, there is a vast right wing conspiracy. Sid",
        "body": "Orl could send the endless pieces on Obama and his troubles or Haaretz on the new negotiations. l'll skip the torrent of Obama pieces (see Politico lead piece today, if you" +
        "want to catch the full updraft of new conventional wisdom), but include Haaretz below from its editorial editor and Teddy Kollek's former spokesman:" +
        "\nWith a victory like this...\n" +
        "The direct negotiations between Israel and the Palestinians have preconditions -dictated by Israel."
    },
    {
        "from": "Sidney Blumenthal",
        "to": "Hillary Clinton",
        "date": "2010-11-23 01:55",
        "subject": "AMERICAN BRIDGE DEBUTS. SID",
        "body": "Effort for Liberal Balance to G.O.P. Groups\n" +
        "Begins\n" + 
        "By MICHAEL LUO\n" + 
        "In what may prove a significant development for the 2012 elections, David Brock, a prominent Democratic political"+
        "operative, says he has amassed $4 million in pledges over the last few weeks and is moving quickly to hire a staff to set"+
        "up what he hopes will become a permanent liberal counterweight over the airwaves to the Republican-leaning outside" +
        "groups that spent so heavily on this year's midterm elections."
    },
    {
        "from": "Cheryl Mills",
        "to": "Hillary Clinton",
        "date": "2010-10-31 06:44",
        "subject": "CAN THE DUDE ABIDE? (NOT THAT I LIKE HER...)",
        "body": "Can the Dude Abide?\n"+
        "By\nMAUREEN DOWD\n"+
        "WASHINGTON\n"+
        "Barack Obama became president by brilliantly telling his own story. To stay president, he will need to show he "+
        "can understand our story.\n"+
        "At first it was exciting that Obama was the sort of brainy, cultivated Democrat who would be at home in a "+
        "West Wing episode.\n" +
        "But now he acts like he really thinks he's on West Wing, gliding through an imaginary, amber-lit set where "+
        "his righteous self-regard is bound to be rewarded by the end of the hour.\n"+
        "Hey, dude, you're a politician. Act like one."
    },
    {
        "from": "Cheryl Mills",
        "to": "Hillary Clinton",
        "date": "2012-01-18 17:16",
        "subject": "KEYSTONE XL PUBLIC REACTION - SUMMARY OF COVERAGE",
        "body": "As of 8:00 p.m. January 18, 2012\n"+
        "SUMMARY OF COVERAGE\n" +
        "A few dominant themes can be seen throughout this afternoon and late evening's media coverage. The majority of the " +
        "coverage reported in a straightforward way that the State Department recommended and the President agreed that the " +
        "permit for the pipeline be denied. Most of the stories quoted the President's statement, many focusing on the fact that " +
        "the permit was not denied on its merit, but rather because there was not enough time to gather the requisite " +
        "information to make the best decision for the American people. Many of these same stories also reported that " +
        "TransCanada will reapply for the permit, and that the President's statement implied that there is still room for an " +
        "approval."
    },
    {
        "from": "Sidney Blumenthal",
        "to": "martilla, john",
        "date": "2012-10-05 02:00",
        "subject": "BIDEN DEBATE (MEMO 2)",
        "body": "1. Biden should adopt a divide and conquer strategy in the debate with Paul Ryan that keeps " +
        "him on the defensive and undermines Romney's motives while staying substantive. At " +
        "the same time, Biden should force Ryan to admit his differences with Romney and that " +
        "Romney embraces his right-wing panaceas. Ryan must be made into the instrument to " +
        "define Romney as two-faced, hypocritical and dangerously far right. Biden can make" +
        "Ryan do this work. Turn him into the witness against Romney.\n" +
        "2. Biden should force Ryan to admit that Romney's statement about Obama cutting " +
        "Medicare by $716 million is not onlyialse but that Ryan knows better and Romney " +
        "should, too. That exact figure is, of course, in Ryan's budget. He knows that Obama has " +
        "not cut Medicare, but is cutting waste, fraud, abuse and overcharging from providers."
    },
    {
        "from": "Sidney Blumenthal",
        "to": "klain, ron",
        "date": "2012-10-19 02:00",
        "subject": "FINAL DEBATE",
        "body": "1. Romney will inevitably falsify, distort and mangle facts on a range of subjects from " +
        "Libya to the defense budget. But why is this debate different from all other debates? In " +
        "the dedicated foreign policy debate, the stakes are higher—America's role in the world.\n" +
        "That makes Romney's errors even more consequential and potentially threatening. And " +
        "that must be an essential predicate of Obama's point when he exposes Romney's " +
        "falsehoods. When Romney lies on domestic policy it's shameful, but when he lies on " +
        "foreign policy it's dangerous.\n" +
        "2. When Romney lies or distorts, he should be revealed as more than misleading. In the " +
        "foreign policy debate, when Romney lies he shows that he's unprepared. That word-" +
        "'unprepared'—is potentially lethal to him. It should be linked logically to his falsehoods, " +
        "which become the proof. When you're untrue, you're unprepared, and when you're " +
        "unprepared you can't be strong."
    },
    {
        "from": "Hillary Clinton",
        "to": "Robert Russo",
        "date": "2012-10-24 03:41",
        "subject": "DEBATE...",
        "body": "I was surprised that Gov. Romney went into the debate playing prevent defense... " +
        "Not attacking but practically " +
        "agreeing much of the time.!. Calm and even passive. President Obama, on the other hand was assertive, used " +
        "snarky one liners and called Romney on the carpet several times... It was a fascinating contrast in contrasts of " +
        "style and strategy.\n" +
        "I thought President Obama wholly owned the debate. I thought he dominated.\n" +
        "But, I also thought it was a reminder of how differently Republicans are working toward the win than we are... I " +
        "think they believe they have their ducks in a row and are setup to win... That they have communicated " +
        "appropriately and have adjusted the intensity and have now a turnout model to succeed on... Believing a share " +
        "of the final few undecideds will join them... So, it's about turnout."
    }
]
